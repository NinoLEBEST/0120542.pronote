
Pronote RP - Lycée de la Saône (v3 Admin)
----------------------------------------

Fichiers:
- index.html : fichier autonome (tout-en-un). Ouvre dans un navigateur.

Comptes:
- Administrateur initial: administration / 140
- Crée ensuite d'autres comptes (professeurs, personnels, élèves) depuis l'onglet Administration.

Fonctionnalités:
- Créer/supprimer comptes (admin)
- Imprimer fiche de connexion (identifiant + mot de passe)
- Gérer présences/absences/retards
- Envoyer alertes (incendie, coupure, protocole hygiène, annonces)
- Thème sombre vert, sauvegarde locale (localStorage)
